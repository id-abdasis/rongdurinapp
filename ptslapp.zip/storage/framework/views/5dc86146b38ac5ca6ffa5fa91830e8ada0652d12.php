<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo e(date('Y')); ?> Sistem Informasi Desa Rongdurin 
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    Dibuat Oleh: <a href="javascript:void(0);">Tim IT Desa Rongdurin</a>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\ptslapp\resources\views/includes/footer.blade.php ENDPATH**/ ?>